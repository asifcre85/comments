-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 13, 2020 at 02:35 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `larticles`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE IF NOT EXISTS `articles` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `title` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `body` text COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `created_at`, `updated_at`, `title`, `body`) VALUES
(1, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Repellat doloribus non dignissimos non.', 'Voluptate doloribus ut ducimus aut. Et incidunt et et sed a rerum et. Accusamus nihil numquam consequatur nesciunt eius animi non.'),
(43, '2020-05-13 00:57:24', '2020-05-13 00:57:24', 'Asif', 'Hi'),
(4, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Et eaque sit impedit quam eum.', 'Repellendus aperiam doloremque mollitia ut pariatur sed recusandae. Illo aut sunt nulla esse voluptatem. Corrupti facere nam alias sequi possimus.'),
(5, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Sint illo nam qui saepe.', 'Debitis tenetur sit deleniti blanditiis voluptate laudantium praesentium. Corporis autem quia omnis illum eum consequuntur. Laborum id ipsum occaecati eos iusto officiis.'),
(6, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Ea sed excepturi est autem.', 'Ut non et voluptate ut. Iure debitis necessitatibus cumque repellendus dolores nobis et dolore. Dolorem beatae neque vel. Nesciunt sed voluptatem est doloribus.'),
(7, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Dolore odit repudiandae officia aut est sed ad.', 'Architecto commodi adipisci delectus perspiciatis aut hic. Et sunt consequatur qui sapiente a. Qui et est est et. Nesciunt quasi in aut et molestias unde quod.'),
(8, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Eius sint at at sequi ullam enim repudiandae.', 'Alias ut iure quisquam ab cum fuga dicta. Alias atque dolores non. Qui voluptatibus ut numquam explicabo sint.'),
(9, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Et consequatur ut et similique eligendi nobis.', 'Magnam placeat impedit pariatur odit quo quos autem omnis. Rerum quis est vero omnis rem voluptatem. At cumque et odio maxime assumenda omnis hic. Iusto illum eveniet sit.'),
(10, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Aut voluptatibus voluptatem temporibus qui dolor.', 'Laudantium repellendus veritatis rerum ipsa facere velit. Reprehenderit voluptatem sed error qui repudiandae deserunt laudantium.'),
(11, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Est quo unde et tempora et.', 'Quis qui est sit veritatis ex quo qui. Molestiae consequatur eveniet at assumenda. Aut rerum provident itaque tempora.'),
(12, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Et sit qui cupiditate enim.', 'Explicabo vel temporibus repellat cupiditate eligendi. Vel dolor qui eum. Quod sint natus et est illo doloribus. Inventore qui non nam alias est odit.'),
(13, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Consequatur at iusto ipsam.', 'Et numquam quis neque adipisci rerum. Enim quis ad at et ipsa rerum repellat non. Minus voluptas fugit eum dicta maxime est. Esse corrupti eos asperiores neque pariatur dolore quisquam deserunt.'),
(14, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Ut sed aut nisi est voluptatem sit.', 'Provident neque libero atque illo voluptatem. In unde eius id cum.'),
(15, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Non aspernatur expedita ut.', 'Nesciunt architecto dolor vel saepe. Quaerat ex beatae quam voluptatem quaerat totam iste. Esse distinctio cupiditate aliquid dolores omnis veritatis. Consequatur impedit aut et.'),
(16, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Ut aspernatur excepturi aliquid magni odit.', 'At dolor animi aut voluptas. Autem quidem dolorum quae iure. Ut enim aliquid consequuntur sed non fugiat et inventore.'),
(17, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Error repellendus placeat ipsam.', 'Et qui qui quia reiciendis. Quia doloribus cupiditate totam repudiandae impedit ullam reprehenderit. Doloremque et iste aliquam.'),
(18, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Qui qui cumque temporibus non quos.', 'Aut nisi et error sequi. Consequatur et eos et fugiat officia aliquid. Et rerum iusto ut rerum. Minus ipsam nihil eos ad quia maxime voluptas voluptate. Quos expedita rem odio explicabo aliquid quia.'),
(19, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Perspiciatis in possimus sint odio.', 'Eveniet nihil labore eius delectus recusandae odio omnis. Minima in ex qui qui suscipit aut autem. Quia veritatis id itaque sequi voluptas iste. Necessitatibus qui id quos accusantium.'),
(20, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Iure assumenda illo ea perferendis.', 'Harum soluta qui voluptatem nihil nemo. Tempore et expedita perspiciatis molestiae omnis ea. Ab quo illo sed deleniti in.'),
(21, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Labore voluptatem voluptatem commodi sint quasi.', 'Beatae nihil hic omnis necessitatibus exercitationem. Ut in et nam. Velit provident animi rerum quam autem. Alias aut veniam porro qui adipisci.'),
(22, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Aut occaecati non ratione inventore.', 'Voluptas quo dolorum dolores a culpa non cumque est. Et aut nihil quo atque id aut unde. Et voluptatem similique quia ut et voluptatibus commodi.'),
(23, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Sed architecto enim qui et nisi neque.', 'Dignissimos et assumenda id minima quia commodi eveniet. Consectetur vitae rerum ullam qui. Ut et perferendis qui assumenda magnam enim ipsum ut. Et sit dicta ea excepturi.'),
(24, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Voluptatibus unde amet et labore et aut eos eum.', 'Eligendi laudantium eos qui qui. Ea occaecati officiis quaerat ut tenetur numquam. Odit impedit rerum id dolore. Laboriosam eaque dolorum amet aut odio.'),
(25, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Ex sunt id saepe in vel molestias adipisci.', 'Et illo harum magnam porro aspernatur non. Voluptatem cum inventore fugit pariatur enim quibusdam sit. Consequatur aut veritatis tempora eaque velit corrupti.'),
(26, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Ea optio voluptate ratione sint nam.', 'Dolorem et pariatur quod dicta nulla vel voluptatem. Ab libero eius aliquam. Quos itaque dignissimos sed veniam sed nisi nihil. Consequuntur accusamus aut eos quo rerum.'),
(27, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Aspernatur provident inventore sunt est nam.', 'Animi sapiente omnis voluptatem omnis optio eius modi. Officiis alias vitae a voluptas magnam laborum. Ut quis facere blanditiis quis voluptatem. Itaque quisquam illum id dolor qui.'),
(28, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Qui aliquid et dolorem quidem.', 'Esse natus amet sunt. Facere provident aspernatur tempore fuga est qui. Sed a praesentium itaque.'),
(29, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Quo omnis delectus nesciunt maiores nemo qui.', 'Aut ut voluptatem suscipit et vitae. Aut ea consequatur libero rerum. Sunt blanditiis at est. Minima mollitia praesentium non sed facilis.'),
(30, '2020-03-23 22:05:13', '2020-03-23 22:05:13', 'Dolor quae dolor qui eveniet quidem.', 'Commodi corporis corporis in dicta. Eum exercitationem omnis nisi non quia vitae provident. Corporis quae ut voluptatum quisquam id repellat. Aut soluta ut aut ea quo consequatur.');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2020_03_24_024404_create_articles_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
