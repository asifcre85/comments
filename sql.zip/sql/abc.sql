-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jul 13, 2020 at 02:07 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `abc`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

DROP TABLE IF EXISTS `books`;
CREATE TABLE IF NOT EXISTS `books` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `name`, `author`, `created_at`, `updated_at`) VALUES
(1, 'a', 'aa', '2020-07-13 00:13:06', '2020-07-13 00:13:06');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2016_06_01_000001_create_oauth_auth_codes_table', 1),
(4, '2016_06_01_000002_create_oauth_access_tokens_table', 1),
(5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1),
(6, '2016_06_01_000004_create_oauth_clients_table', 1),
(7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1),
(8, '2019_03_21_153350_create_books_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `oauth_access_tokens`
--

DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_access_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_access_tokens_user_id_index` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_access_tokens`
--

INSERT INTO `oauth_access_tokens` (`id`, `user_id`, `client_id`, `name`, `scopes`, `revoked`, `created_at`, `updated_at`, `expires_at`) VALUES
('3e780b18adb788d042a9e25f9634a4961cef76f3338148b35dc9563de558ff6b2aa6c11a2e10593a', 1, 1, 'MyApp', '[]', 0, '2020-05-28 06:21:41', '2020-05-28 06:21:41', '2021-05-28 11:51:41'),
('2b9ac0005316250d0277041fbd647491672925e7c33a997c4539dc25a2f0e45b98ed4067d4bcd7d7', 1, 1, 'MyApp', '[]', 0, '2020-05-28 06:23:04', '2020-05-28 06:23:04', '2021-05-28 11:53:04'),
('6adef7e6953875d25820c89b4d60f7bd31833be05aed42f0a0649b758efa8ac8898f8613a26d30a6', 1, 1, 'MyApp', '[]', 0, '2020-05-28 06:32:23', '2020-05-28 06:32:23', '2021-05-28 12:02:23'),
('23b4bfca03454beef044e2471309281a45d9d464af9c22fa8348b035627897953ab777fc6ebd1685', 2, 1, 'MyApp', '[]', 0, '2020-05-30 08:55:38', '2020-05-30 08:55:38', '2021-05-30 14:25:38'),
('9c3ccf010ecd38de6d11fd8b6a77fd9fe905ee68bc7f2677ca11bf0b0c906db322cc9880be2ecd5e', 2, 1, 'MyApp', '[]', 0, '2020-05-30 08:59:09', '2020-05-30 08:59:09', '2021-05-30 14:29:09'),
('c2c1e0e63b39ec8ecfc6aca900a15854141d4f4bd3e28a8de1cb4c876a6647d23516aa4c73d2966f', 2, 1, 'MyApp', '[]', 0, '2020-05-30 09:12:00', '2020-05-30 09:12:00', '2021-05-30 14:42:00'),
('73312fcdb2dd15db90ac1d35c9e5d76e7851266756fb02af54ed289226d0f7359b690a5dfdeb6040', 3, 1, 'MyApp', '[]', 0, '2020-05-30 09:19:04', '2020-05-30 09:19:04', '2021-05-30 14:49:04'),
('04faa4fc5b1731577624a5703e34f07c4e156e0aa377b0a19f8b336629fcabac0db0b18f4ce378a7', 3, 1, 'MyApp', '[]', 0, '2020-05-30 09:19:41', '2020-05-30 09:19:41', '2021-05-30 14:49:41'),
('c936ff8eb9879ad48b3d68ea6a37c746be8963a9c499a56ada780424ab0c29fd00071f6f816d6013', 4, 1, 'MyApp', '[]', 0, '2020-05-30 09:21:08', '2020-05-30 09:21:08', '2021-05-30 14:51:08'),
('14ccda8131d3b85a22ef49cab71104ca4223aea96f04c37b4df538ff1e0cba938ac0d8561a5243ea', 4, 1, 'MyApp', '[]', 0, '2020-05-30 09:21:25', '2020-05-30 09:21:25', '2021-05-30 14:51:25'),
('ce93a1d03080ce3cf3c0d789afdb239fc883a6cee41b3e605573516495cc4c0edbafd0200e862cfd', 5, 1, 'MyApp', '[]', 0, '2020-05-30 09:24:32', '2020-05-30 09:24:32', '2021-05-30 14:54:32'),
('10d8bfa60558fc167847843f92fd109b1e83b042c4e3197e4adc9480e762754758a9d096aae05809', 5, 1, 'MyApp', '[]', 0, '2020-05-30 09:25:03', '2020-05-30 09:25:03', '2021-05-30 14:55:03'),
('6f41f33fe4f338be11ff1caee9dc34e6d7d1912ae238c6f87e1af2544aac050a287fa4be73725cca', 6, 1, 'MyApp', '[]', 0, '2020-05-31 21:16:58', '2020-05-31 21:16:58', '2021-06-01 02:46:58'),
('51f3b8578be3632594df143dedc880a7a98f7bcbbf38f398113b7121688b0cf788e14e766ae3aad3', 6, 1, 'MyApp', '[]', 0, '2020-05-31 21:18:23', '2020-05-31 21:18:23', '2021-06-01 02:48:23'),
('5eb825952707de0c81c4dd9dd3909e98ca47fd4dbee9f05bbae5b2085d9320c714a8fe6df35de461', 1, 1, 'MyApp', '[]', 0, '2020-07-12 23:53:11', '2020-07-12 23:53:11', '2021-07-13 05:23:11'),
('85296ba2c21b76052cc6e6f37f32800bb5944091af5ba6a4b52831de884dc70838804da886b37f69', 1, 1, 'MyApp', '[]', 0, '2020-07-13 00:01:23', '2020-07-13 00:01:23', '2021-07-13 05:31:23');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_auth_codes`
--

DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE IF NOT EXISTS `oauth_auth_codes` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oauth_clients`
--

DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE IF NOT EXISTS `oauth_clients` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_clients_user_id_index` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_clients`
--

INSERT INTO `oauth_clients` (`id`, `user_id`, `name`, `secret`, `redirect`, `personal_access_client`, `password_client`, `revoked`, `created_at`, `updated_at`) VALUES
(1, NULL, 'Laravel Personal Access Client', 'm6vcwCO6nzwP5LaQvnBYc7XdGtykrKHyoHymrJ4E', 'http://localhost', 1, 0, 0, '2020-05-28 06:00:47', '2020-05-28 06:00:47'),
(2, NULL, 'Laravel Password Grant Client', 'vugps3G8MgwcMDEApzSlS2gr4msV29s4tNoZLF73', 'http://localhost', 0, 1, 0, '2020-05-28 06:00:47', '2020-05-28 06:00:47');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_personal_access_clients`
--

DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE IF NOT EXISTS `oauth_personal_access_clients` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_personal_access_clients_client_id_index` (`client_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `oauth_personal_access_clients`
--

INSERT INTO `oauth_personal_access_clients` (`id`, `client_id`, `created_at`, `updated_at`) VALUES
(1, 1, '2020-05-28 06:00:47', '2020-05-28 06:00:47');

-- --------------------------------------------------------

--
-- Table structure for table `oauth_refresh_tokens`
--

DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE IF NOT EXISTS `oauth_refresh_tokens` (
  `id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `oauth_refresh_tokens_access_token_id_index` (`access_token_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'a', 'a@gmail.com', NULL, '$2y$10$Vw.6cbnAHxIErSZH1RvgqezRg5l6tzRvUbD7/gg/O3fnkmB6DoG9q', NULL, '2020-07-12 23:53:04', '2020-07-12 23:53:04');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
